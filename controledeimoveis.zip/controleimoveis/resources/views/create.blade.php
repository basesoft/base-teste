
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Cadastrar Dados</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">  
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script  data-src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.0/jquery.mask.js"></script>

<script>
function formatar(mascara, documento){
  var i = documento.value.length;
  var out = mascara.substring(0,1);
  var text = mascara.substring(i)
  
  if (text.substring(0,1) != out){
            documento.value += text.substring(0,1);
  }
  
}
</script>

  </head>
  <body>
    <div class="container">
      <h2>Realizar Cadastro de Imóvel</h2><br/>
      <form method="post" action="{{url('dados')}}" enctype="multipart/form-data">
        @csrf
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="endereco">Endereço:</label>
            <input type="text" class="form-control" name="endereco">
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Bairro">Bairro:</label>
              <input type="text" class="form-control" name="bairro">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Municipio">Municipio:</label>
              <input type="text" class="form-control" name="municipio">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Estado ">Estado:</label>
              <input type="text" class="form-control" name="estado">
            </div>
          </div>
       <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="CEP">CEP:</label>
              <input type="text" class="form-control" name="cep" OnKeyPress="formatar('#####-###', this)">
            </div>
          </div>
         <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
                <lable>Tipo do Imóvel:</lable>
                <select name="tipo_imovel">
                  <option value="Apartamento">Apartamento</option>
                  <option value="Casa">Casa</option>
                  <option value="Sitio">Sitio</option>  
                  <option value="Andar">Andar</option>  
                </select>
            </div>
        </div>
           <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Nome do Proprietario">Nome do Proprietario:</label>
              <input type="text" class="form-control" name="nome_proprietario">
            </div>
          </div>

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Cadastrar</button>
            <a href="{{action('DadoController@index')}}" class="btn btn-warning">Voltar</a>
          </div>
        </div>
      </form>
    </div>
    <script type="text/javascript">  
        $('#datepicker').datepicker({ 
            autoclose: true,   
            format: 'dd-mm-yyyy'  
         });  
    </script>
  </body>
</html>