<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Editar </title>
     <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">  
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script  data-src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>  
  </head>
  <body>
    <div class="container">
      <h2>Editar cadastro</h2><br  />
        <form method="post" action="{{action('DadoController@update', $id)}}">
        @csrf
        <input name="_method" type="hidden" value="PATCH">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="endereco">Endereço:</label>
            <input type="text" class="form-control" name="endereco" value="{{$dado->endereco}}">
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Bairro">Bairro:</label>
              <input type="text" class="form-control" name="bairro"  value="{{$dado->bairro}}">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Municipio">Municipio:</label>
              <input type="text" class="form-control" name="municipio"  value="{{$dado->municipio}}">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Estado ">Estado:</label>
              <input type="text" class="form-control" name="estado" value="{{$dado->estado}}">
            </div>
          </div>
       <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="CEP">CEP:</label>
              <input type="text" class="form-control" name="cep" value="{{$dado->cep}}"  required pattern="\d{5}-\d{3}">
            </div>
          </div>
         <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
                <lable>Tipo do Imóvel:</lable>
                <select name="tipo_imovel">
                  <option value="Apartamento"  @if($dado->tipo_imovel=="Apartamento") selected @endif>Apartamento</option>
                  <option value="Casa"  @if($dado->tipo_imovel=="Casa") selected @endif>Casa</option>
                  <option value="Sitio" @if($dado->tipo_imovel=="Sitio") selected @endif>Sitio</option>  
                  <option value="Andar" @if($dado->tipo_imovel=="Andar") selected @endif>Andar</option>

                </select>
            </div>
        </div>
           <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Nome do Proprietario">Nome do Proprietario:</label>
              <input type="text" class="form-control" name="nome_proprietario"  value="{{$dado->nome_proprietario}}">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Atualizar dados</button>
          </div>
        </div>
      </form>
    </div>
  </body>
</html>