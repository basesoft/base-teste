<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Inicio</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">  
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <link href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet"> 
    <script  data-src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>  
  </head>
  <body>
    <br />
    @if (\Session::has('success'))
      <div class="alert alert-success">
        <p>{{ \Session::get('success') }}</p>
      </div><br />
     @endif<center>
<h1>Controle de Imóveis</h1>
</center>
    <div align="right" class="container"> <a href="{{action('DadoController@create')}}" class="btn btn-success">Cadastrar</a><br><br>
    <table class="table table-striped" id="tbl_avaliar">
    <thead>
      <tr align="">
        <th>Id</th>
        <th>Endereco</th>
        <th>Bairro</th>
        <th>Municipio</th>
        <th>Estado</th>
        <th>Cep</th>
        <th>Tipo Imóvel</th>
        <th>Proprietário</th>
        <th>Editar</th>
        <th>Excluir</th>
      </tr>
    </thead>
    <tbody>
      
      @foreach($dados as $dado)
      <tr align="">
        <td>{{$dado['id']}}</td>
        <td>{{$dado['endereco']}}</td>
        <td>{{$dado['bairro']}}</td>
        <td>{{$dado['municipio']}}</td>
        <td>{{$dado['estado']}}</td>
        <td>{{$dado['cep']}}</td>
        <td>{{$dado['tipo_imovel']}}</td>
        <td>{{$dado['nome_proprietario']}}</td>
        
        <td><a href="{{action('DadoController@edit', $dado['id'])}}" class="btn btn-primary">*</a></td>
        <td>
          <form action="{{action('DadoController@destroy', $dado['id'])}}" method="post">
            @csrf
            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit">x</button>
          </form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
  </div>
  </body>

  <script src="//code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
  <script>
  $(document).ready(function(){
      $('#tbl_avaliar').DataTable({
          "language": {
                "lengthMenu": "Exibindo _MENU_ registros na tabela.",
                "zeroRecords": "Nenhum registo encontrado!",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "infoEmpty": "Nenhum registro disponível",
                "infoFiltered": "(filtrado de _MAX_ registros no total)"
            }
        });
  });
  </script>

</html>