<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Inicio</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">  
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <link href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet"> 
    <script  data-src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>  
  </head>
  <body>
    <br />
    <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
     <?php endif; ?><center>
<h1>Controle de Imóveis</h1>
</center>
    <div align="right" class="container"> <a href="<?php echo e(action('DadoController@create')); ?>" class="btn btn-success">Cadastrar</a><br><br>
    <table class="table table-striped" id="tbl_avaliar">
    <thead>
      <tr align="">
        <th>Id</th>
        <th>Endereco</th>
        <th>Bairro</th>
        <th>Municipio</th>
        <th>Estado</th>
        <th>Cep</th>
        <th>Tipo Imóvel</th>
        <th>Proprietário</th>
        <th>Editar</th>
        <th>Excluir</th>
      </tr>
    </thead>
    <tbody>
      
      <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr align="">
        <td><?php echo e($dado['id']); ?></td>
        <td><?php echo e($dado['endereco']); ?></td>
        <td><?php echo e($dado['bairro']); ?></td>
        <td><?php echo e($dado['municipio']); ?></td>
        <td><?php echo e($dado['estado']); ?></td>
        <td><?php echo e($dado['cep']); ?></td>
        <td><?php echo e($dado['tipo_imovel']); ?></td>
        <td><?php echo e($dado['nome_proprietario']); ?></td>
        
        <td><a href="<?php echo e(action('DadoController@edit', $dado['id'])); ?>" class="btn btn-primary">*</a></td>
        <td>
          <form action="<?php echo e(action('DadoController@destroy', $dado['id'])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit">x</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
  </body>

  <script src="//code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
  <script>
  $(document).ready(function(){
      $('#tbl_avaliar').DataTable({
          "language": {
                "lengthMenu": "Exibindo _MENU_ registros na tabela.",
                "zeroRecords": "Nenhum registo encontrado!",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "infoEmpty": "Nenhum registro disponível",
                "infoFiltered": "(filtrado de _MAX_ registros no total)"
            }
        });
  });
  </script>

</html><?php /**PATH C:\xampp\htdocs\controleimoveis\resources\views/index.blade.php ENDPATH**/ ?>