<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Editar </title>
     <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">  
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script  data-src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>  
  </head>
  <body>
    <div class="container">
      <h2>Editar cadastro</h2><br  />
        <form method="post" action="<?php echo e(action('DadoController@update', $id)); ?>">
        <?php echo csrf_field(); ?>
        <input name="_method" type="hidden" value="PATCH">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="endereco">Endereço:</label>
            <input type="text" class="form-control" name="endereco" value="<?php echo e($dado->endereco); ?>">
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Bairro">Bairro:</label>
              <input type="text" class="form-control" name="bairro"  value="<?php echo e($dado->bairro); ?>">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Municipio">Municipio:</label>
              <input type="text" class="form-control" name="municipio"  value="<?php echo e($dado->municipio); ?>">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Estado ">Estado:</label>
              <input type="text" class="form-control" name="estado" value="<?php echo e($dado->estado); ?>">
            </div>
          </div>
       <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="CEP">CEP:</label>
              <input type="text" class="form-control" name="cep" value="<?php echo e($dado->cep); ?>"  required pattern="\d{5}-\d{3}">
            </div>
          </div>
         <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
                <lable>Tipo do Imóvel:</lable>
                <select name="tipo_imovel">
                  <option value="Apartamento"  <?php if($dado->tipo_imovel=="Apartamento"): ?> selected <?php endif; ?>>Apartamento</option>
                  <option value="Casa"  <?php if($dado->tipo_imovel=="Casa"): ?> selected <?php endif; ?>>Casa</option>
                  <option value="Sitio" <?php if($dado->tipo_imovel=="Sitio"): ?> selected <?php endif; ?>>Sitio</option>  
                  <option value="Andar" <?php if($dado->tipo_imovel=="Andar"): ?> selected <?php endif; ?>>Andar</option>

                </select>
            </div>
        </div>
           <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Nome do Proprietario">Nome do Proprietario:</label>
              <input type="text" class="form-control" name="nome_proprietario"  value="<?php echo e($dado->nome_proprietario); ?>">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Atualizar dados</button>
          </div>
        </div>
      </form>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\controleimoveis\resources\views/edit.blade.php ENDPATH**/ ?>